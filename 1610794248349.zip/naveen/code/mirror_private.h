/*
 * mirror_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mirror".
 *
 * Model version              : 1.1
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sat Jan 16 14:48:49 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_mirror_private_h_
#define RTW_HEADER_mirror_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "mirror.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

extern void mirror_IfActionSubsystem_Init(B_IfActionSubsystem_mirror_T *localB,
  P_IfActionSubsystem_mirror_T *localP);
extern void mirror_IfActionSubsystem(real_T rtu_In1,
  B_IfActionSubsystem_mirror_T *localB);
extern void mirror_left_mirror_Init(B_left_mirror_mirror_T *localB,
  P_left_mirror_mirror_T *localP);
extern void mirror_left_mirror(real_T rtu_Enable, real_T rtu_Input2,
  B_left_mirror_mirror_T *localB, P_left_mirror_mirror_T *localP);

#endif                                 /* RTW_HEADER_mirror_private_h_ */
