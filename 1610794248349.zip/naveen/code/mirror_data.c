/*
 * mirror_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mirror".
 *
 * Model version              : 1.1
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sat Jan 16 14:48:49 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "mirror.h"
#include "mirror_private.h"

/* Block parameters (default storage) */
P_mirror_T mirror_P = {
  /* Start of '<S1>/right_mirror' */
  {
    /* Expression: 1
     * Referenced by: '<S3>/Constant1'
     */
    1.0,

    /* Expression: -1
     * Referenced by: '<S3>/Constant2'
     */
    -1.0,

    /* Expression: 2
     * Referenced by: '<S3>/Constant3'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S3>/Constant4'
     */
    0.0,

    /* Start of '<S2>/If Action Subsystem3' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S11>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S2>/If Action Subsystem3' */

    /* Start of '<S2>/If Action Subsystem1' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S9>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S2>/If Action Subsystem1' */

    /* Start of '<S2>/If Action Subsystem2' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S10>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S2>/If Action Subsystem2' */

    /* Start of '<S2>/If Action Subsystem' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S8>/Out1'
       */
      0.0
    }
    /* End of '<S2>/If Action Subsystem' */
  }
  ,

  /* End of '<S1>/right_mirror' */

  /* Start of '<S1>/left_mirror' */
  {
    /* Expression: 1
     * Referenced by: '<S2>/Constant1'
     */
    1.0,

    /* Expression: -1
     * Referenced by: '<S2>/Constant2'
     */
    -1.0,

    /* Expression: 2
     * Referenced by: '<S2>/Constant3'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S2>/Constant4'
     */
    0.0,

    /* Start of '<S2>/If Action Subsystem3' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S7>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S2>/If Action Subsystem3' */

    /* Start of '<S2>/If Action Subsystem1' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S5>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S2>/If Action Subsystem1' */

    /* Start of '<S2>/If Action Subsystem2' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S6>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S2>/If Action Subsystem2' */

    /* Start of '<S2>/If Action Subsystem' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S4>/Out1'
       */
      0.0
    }
    /* End of '<S2>/If Action Subsystem' */
  }
  /* End of '<S1>/left_mirror' */
};
