/*
 * mirror.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mirror".
 *
 * Model version              : 1.1
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sat Jan 16 14:48:49 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "mirror.h"
#include "mirror_private.h"

/* Block signals (default storage) */
B_mirror_T mirror_B;

/* External inputs (root inport signals with default storage) */
ExtU_mirror_T mirror_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_mirror_T mirror_Y;

/* Real-time model */
static RT_MODEL_mirror_T mirror_M_;
RT_MODEL_mirror_T *const mirror_M = &mirror_M_;

/*
 * System initialize for action system:
 *    '<S2>/If Action Subsystem'
 *    '<S2>/If Action Subsystem2'
 *    '<S2>/If Action Subsystem1'
 *    '<S2>/If Action Subsystem3'
 *    '<S3>/If Action Subsystem'
 *    '<S3>/If Action Subsystem2'
 *    '<S3>/If Action Subsystem1'
 *    '<S3>/If Action Subsystem3'
 */
void mirror_IfActionSubsystem_Init(B_IfActionSubsystem_mirror_T *localB,
  P_IfActionSubsystem_mirror_T *localP)
{
  /* SystemInitialize for Outport: '<S4>/Out1' incorporates:
   *  Inport: '<S4>/In1'
   */
  localB->In1 = localP->Out1_Y0;
}

/*
 * Output and update for action system:
 *    '<S2>/If Action Subsystem'
 *    '<S2>/If Action Subsystem2'
 *    '<S2>/If Action Subsystem1'
 *    '<S2>/If Action Subsystem3'
 *    '<S3>/If Action Subsystem'
 *    '<S3>/If Action Subsystem2'
 *    '<S3>/If Action Subsystem1'
 *    '<S3>/If Action Subsystem3'
 */
void mirror_IfActionSubsystem(real_T rtu_In1, B_IfActionSubsystem_mirror_T
  *localB)
{
  /* Inport: '<S4>/In1' */
  localB->In1 = rtu_In1;
}

/*
 * System initialize for enable system:
 *    '<S1>/left_mirror'
 *    '<S1>/right_mirror'
 */
void mirror_left_mirror_Init(B_left_mirror_mirror_T *localB,
  P_left_mirror_mirror_T *localP)
{
  /* SystemInitialize for IfAction SubSystem: '<S2>/If Action Subsystem' */
  mirror_IfActionSubsystem_Init(&localB->IfActionSubsystem,
    &localP->IfActionSubsystem);

  /* End of SystemInitialize for SubSystem: '<S2>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S2>/If Action Subsystem2' */
  mirror_IfActionSubsystem_Init(&localB->IfActionSubsystem2,
    &localP->IfActionSubsystem2);

  /* End of SystemInitialize for SubSystem: '<S2>/If Action Subsystem2' */

  /* SystemInitialize for IfAction SubSystem: '<S2>/If Action Subsystem1' */
  mirror_IfActionSubsystem_Init(&localB->IfActionSubsystem1,
    &localP->IfActionSubsystem1);

  /* End of SystemInitialize for SubSystem: '<S2>/If Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S2>/If Action Subsystem3' */
  mirror_IfActionSubsystem_Init(&localB->IfActionSubsystem3,
    &localP->IfActionSubsystem3);

  /* End of SystemInitialize for SubSystem: '<S2>/If Action Subsystem3' */
}

/*
 * Output and update for enable system:
 *    '<S1>/left_mirror'
 *    '<S1>/right_mirror'
 */
void mirror_left_mirror(real_T rtu_Enable, real_T rtu_Input2,
  B_left_mirror_mirror_T *localB, P_left_mirror_mirror_T *localP)
{
  /* Outputs for Enabled SubSystem: '<S1>/left_mirror' incorporates:
   *  EnablePort: '<S2>/Enable'
   */
  if (rtu_Enable > 0.0) {
    /* If: '<S2>/If' incorporates:
     *  Constant: '<S2>/Constant1'
     *  Constant: '<S2>/Constant2'
     *  Constant: '<S2>/Constant3'
     *  Constant: '<S2>/Constant4'
     */
    if (rtu_Input2 == 1.0) {
      /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem' incorporates:
       *  ActionPort: '<S4>/Action Port'
       */
      mirror_IfActionSubsystem(localP->Constant1_Value,
        &localB->IfActionSubsystem);

      /* End of Outputs for SubSystem: '<S2>/If Action Subsystem' */
    } else if (rtu_Input2 == -1.0) {
      /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S6>/Action Port'
       */
      mirror_IfActionSubsystem(localP->Constant2_Value,
        &localB->IfActionSubsystem2);

      /* End of Outputs for SubSystem: '<S2>/If Action Subsystem2' */
    } else if (rtu_Input2 == 2.0) {
      /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S5>/Action Port'
       */
      mirror_IfActionSubsystem(localP->Constant3_Value,
        &localB->IfActionSubsystem1);

      /* End of Outputs for SubSystem: '<S2>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S7>/Action Port'
       */
      mirror_IfActionSubsystem(localP->Constant4_Value,
        &localB->IfActionSubsystem3);

      /* End of Outputs for SubSystem: '<S2>/If Action Subsystem3' */
    }

    /* End of If: '<S2>/If' */
  }

  /* End of Outputs for SubSystem: '<S1>/left_mirror' */
}

/* Model step function */
void mirror_step(void)
{
  /* Outputs for Atomic SubSystem: '<Root>/mirror' */
  /* Outputs for Enabled SubSystem: '<S1>/right_mirror' */
  /* Inport: '<Root>/Input1' incorporates:
   *  Inport: '<Root>/Input2'
   */
  mirror_left_mirror(mirror_U.Input1, mirror_U.Input2, &mirror_B.right_mirror,
                     &mirror_P.right_mirror);

  /* End of Outputs for SubSystem: '<S1>/right_mirror' */

  /* Outputs for Enabled SubSystem: '<S1>/left_mirror' */
  /* Inport: '<Root>/Input3' incorporates:
   *  Inport: '<Root>/Input4'
   */
  mirror_left_mirror(mirror_U.Input3, mirror_U.Input4, &mirror_B.left_mirror,
                     &mirror_P.left_mirror);

  /* End of Outputs for SubSystem: '<S1>/left_mirror' */
  /* End of Outputs for SubSystem: '<Root>/mirror' */

  /* Outport: '<Root>/Output28' */
  mirror_Y.Output28 = mirror_B.right_mirror.IfActionSubsystem.In1;

  /* Outport: '<Root>/Output29' */
  mirror_Y.Output29 = mirror_B.right_mirror.IfActionSubsystem2.In1;

  /* Outport: '<Root>/Output30' */
  mirror_Y.Output30 = mirror_B.right_mirror.IfActionSubsystem1.In1;

  /* Outport: '<Root>/Output31' */
  mirror_Y.Output31 = mirror_B.right_mirror.IfActionSubsystem3.In1;

  /* Outport: '<Root>/Output1' */
  mirror_Y.Output1 = mirror_B.left_mirror.IfActionSubsystem.In1;

  /* Outport: '<Root>/Output2' */
  mirror_Y.Output2 = mirror_B.left_mirror.IfActionSubsystem2.In1;

  /* Outport: '<Root>/Output3' */
  mirror_Y.Output3 = mirror_B.left_mirror.IfActionSubsystem1.In1;

  /* Outport: '<Root>/Output4' */
  mirror_Y.Output4 = mirror_B.left_mirror.IfActionSubsystem3.In1;

  /* Matfile logging */
  rt_UpdateTXYLogVars(mirror_M->rtwLogInfo, (&mirror_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.2s, 0.0s] */
    if ((rtmGetTFinal(mirror_M)!=-1) &&
        !((rtmGetTFinal(mirror_M)-mirror_M->Timing.taskTime0) >
          mirror_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(mirror_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++mirror_M->Timing.clockTick0)) {
    ++mirror_M->Timing.clockTickH0;
  }

  mirror_M->Timing.taskTime0 = mirror_M->Timing.clockTick0 *
    mirror_M->Timing.stepSize0 + mirror_M->Timing.clockTickH0 *
    mirror_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void mirror_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)mirror_M, 0,
                sizeof(RT_MODEL_mirror_T));
  rtmSetTFinal(mirror_M, 10.0);
  mirror_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    mirror_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(mirror_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(mirror_M->rtwLogInfo, (NULL));
    rtliSetLogT(mirror_M->rtwLogInfo, "tout");
    rtliSetLogX(mirror_M->rtwLogInfo, "");
    rtliSetLogXFinal(mirror_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(mirror_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(mirror_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(mirror_M->rtwLogInfo, 0);
    rtliSetLogDecimation(mirror_M->rtwLogInfo, 1);
    rtliSetLogY(mirror_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(mirror_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(mirror_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &mirror_B), 0,
                sizeof(B_mirror_T));

  /* external inputs */
  (void)memset(&mirror_U, 0, sizeof(ExtU_mirror_T));

  /* external outputs */
  (void) memset((void *)&mirror_Y, 0,
                sizeof(ExtY_mirror_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(mirror_M->rtwLogInfo, 0.0, rtmGetTFinal
    (mirror_M), mirror_M->Timing.stepSize0, (&rtmGetErrorStatus(mirror_M)));

  /* SystemInitialize for Atomic SubSystem: '<Root>/mirror' */
  /* SystemInitialize for Enabled SubSystem: '<S1>/right_mirror' */
  mirror_left_mirror_Init(&mirror_B.right_mirror, &mirror_P.right_mirror);

  /* End of SystemInitialize for SubSystem: '<S1>/right_mirror' */

  /* SystemInitialize for Enabled SubSystem: '<S1>/left_mirror' */
  mirror_left_mirror_Init(&mirror_B.left_mirror, &mirror_P.left_mirror);

  /* End of SystemInitialize for SubSystem: '<S1>/left_mirror' */
  /* End of SystemInitialize for SubSystem: '<Root>/mirror' */

  /* SystemInitialize for Outport: '<Root>/Output28' incorporates:
   *  Inport: '<S8>/In1'
   */
  mirror_Y.Output28 = mirror_B.right_mirror.IfActionSubsystem.In1;

  /* SystemInitialize for Outport: '<Root>/Output29' incorporates:
   *  Inport: '<S10>/In1'
   */
  mirror_Y.Output29 = mirror_B.right_mirror.IfActionSubsystem2.In1;

  /* SystemInitialize for Outport: '<Root>/Output30' incorporates:
   *  Inport: '<S9>/In1'
   */
  mirror_Y.Output30 = mirror_B.right_mirror.IfActionSubsystem1.In1;

  /* SystemInitialize for Outport: '<Root>/Output31' incorporates:
   *  Inport: '<S11>/In1'
   */
  mirror_Y.Output31 = mirror_B.right_mirror.IfActionSubsystem3.In1;

  /* SystemInitialize for Outport: '<Root>/Output1' */
  mirror_Y.Output1 = mirror_B.left_mirror.IfActionSubsystem.In1;

  /* SystemInitialize for Outport: '<Root>/Output2' incorporates:
   *  Inport: '<S6>/In1'
   */
  mirror_Y.Output2 = mirror_B.left_mirror.IfActionSubsystem2.In1;

  /* SystemInitialize for Outport: '<Root>/Output3' incorporates:
   *  Inport: '<S5>/In1'
   */
  mirror_Y.Output3 = mirror_B.left_mirror.IfActionSubsystem1.In1;

  /* SystemInitialize for Outport: '<Root>/Output4' incorporates:
   *  Inport: '<S7>/In1'
   */
  mirror_Y.Output4 = mirror_B.left_mirror.IfActionSubsystem3.In1;
}

/* Model terminate function */
void mirror_terminate(void)
{
  /* (no terminate code required) */
}
