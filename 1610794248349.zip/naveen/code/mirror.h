/*
 * mirror.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mirror".
 *
 * Model version              : 1.1
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sat Jan 16 14:48:49 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_mirror_h_
#define RTW_HEADER_mirror_h_
#include <string.h>
#include <float.h>
#include <stddef.h>
#ifndef mirror_COMMON_INCLUDES_
#define mirror_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* mirror_COMMON_INCLUDES_ */

#include "mirror_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block signals for system '<S2>/If Action Subsystem' */
typedef struct {
  real_T In1;                          /* '<S4>/In1' */
} B_IfActionSubsystem_mirror_T;

/* Block signals for system '<S1>/left_mirror' */
typedef struct {
  B_IfActionSubsystem_mirror_T IfActionSubsystem3;/* '<S2>/If Action Subsystem3' */
  B_IfActionSubsystem_mirror_T IfActionSubsystem1;/* '<S2>/If Action Subsystem1' */
  B_IfActionSubsystem_mirror_T IfActionSubsystem2;/* '<S2>/If Action Subsystem2' */
  B_IfActionSubsystem_mirror_T IfActionSubsystem;/* '<S2>/If Action Subsystem' */
} B_left_mirror_mirror_T;

/* Block signals (default storage) */
typedef struct {
  B_left_mirror_mirror_T right_mirror; /* '<S1>/right_mirror' */
  B_left_mirror_mirror_T left_mirror;  /* '<S1>/left_mirror' */
} B_mirror_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T Input1;                       /* '<Root>/Input1' */
  real_T Input2;                       /* '<Root>/Input2' */
  real_T Input3;                       /* '<Root>/Input3' */
  real_T Input4;                       /* '<Root>/Input4' */
} ExtU_mirror_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T Output28;                     /* '<Root>/Output28' */
  real_T Output29;                     /* '<Root>/Output29' */
  real_T Output30;                     /* '<Root>/Output30' */
  real_T Output31;                     /* '<Root>/Output31' */
  real_T Output1;                      /* '<Root>/Output1' */
  real_T Output2;                      /* '<Root>/Output2' */
  real_T Output3;                      /* '<Root>/Output3' */
  real_T Output4;                      /* '<Root>/Output4' */
} ExtY_mirror_T;

/* Parameters for system: '<S2>/If Action Subsystem' */
struct P_IfActionSubsystem_mirror_T_ {
  real_T Out1_Y0;                      /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S4>/Out1'
                                        */
};

/* Parameters for system: '<S1>/left_mirror' */
struct P_left_mirror_mirror_T_ {
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S2>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: -1
                                        * Referenced by: '<S2>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 2
                                        * Referenced by: '<S2>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant4'
                                        */
  P_IfActionSubsystem_mirror_T IfActionSubsystem3;/* '<S2>/If Action Subsystem3' */
  P_IfActionSubsystem_mirror_T IfActionSubsystem1;/* '<S2>/If Action Subsystem1' */
  P_IfActionSubsystem_mirror_T IfActionSubsystem2;/* '<S2>/If Action Subsystem2' */
  P_IfActionSubsystem_mirror_T IfActionSubsystem;/* '<S2>/If Action Subsystem' */
};

/* Parameters (default storage) */
struct P_mirror_T_ {
  P_left_mirror_mirror_T right_mirror; /* '<S1>/right_mirror' */
  P_left_mirror_mirror_T left_mirror;  /* '<S1>/left_mirror' */
};

/* Real-time Model Data Structure */
struct tag_RTM_mirror_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_mirror_T mirror_P;

/* Block signals (default storage) */
extern B_mirror_T mirror_B;

/* External inputs (root inport signals with default storage) */
extern ExtU_mirror_T mirror_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_mirror_T mirror_Y;

/* Model entry point functions */
extern void mirror_initialize(void);
extern void mirror_step(void);
extern void mirror_terminate(void);

/* Real-time Model object */
extern RT_MODEL_mirror_T *const mirror_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('Mirror_99003203/mirror')    - opens subsystem Mirror_99003203/mirror
 * hilite_system('Mirror_99003203/mirror/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Mirror_99003203'
 * '<S1>'   : 'Mirror_99003203/mirror'
 * '<S2>'   : 'Mirror_99003203/mirror/left_mirror'
 * '<S3>'   : 'Mirror_99003203/mirror/right_mirror'
 * '<S4>'   : 'Mirror_99003203/mirror/left_mirror/If Action Subsystem'
 * '<S5>'   : 'Mirror_99003203/mirror/left_mirror/If Action Subsystem1'
 * '<S6>'   : 'Mirror_99003203/mirror/left_mirror/If Action Subsystem2'
 * '<S7>'   : 'Mirror_99003203/mirror/left_mirror/If Action Subsystem3'
 * '<S8>'   : 'Mirror_99003203/mirror/right_mirror/If Action Subsystem'
 * '<S9>'   : 'Mirror_99003203/mirror/right_mirror/If Action Subsystem1'
 * '<S10>'  : 'Mirror_99003203/mirror/right_mirror/If Action Subsystem2'
 * '<S11>'  : 'Mirror_99003203/mirror/right_mirror/If Action Subsystem3'
 */
#endif                                 /* RTW_HEADER_mirror_h_ */
